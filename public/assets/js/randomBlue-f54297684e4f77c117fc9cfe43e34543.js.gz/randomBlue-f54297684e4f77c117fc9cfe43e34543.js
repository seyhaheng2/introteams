/*!
 * Bokeh Random Color (http://themeforest.net/users/imangm)
 * Copyright 2014 ImanGM
 */
 
	// Give a random color to each element
	var randomColor = true;
	var randomHue = 'blue';
